module UNF
  class Normalizer
    VERSION = "0.0.7.5"
  end
end
