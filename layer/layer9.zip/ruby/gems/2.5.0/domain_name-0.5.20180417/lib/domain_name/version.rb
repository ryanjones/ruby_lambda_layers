class DomainName
  VERSION = '0.5.20180417'
end
