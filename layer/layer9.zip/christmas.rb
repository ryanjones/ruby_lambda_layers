class Christmas
  def song
    "FA LA LA LA LA, LA LA LA LA"
  end
end